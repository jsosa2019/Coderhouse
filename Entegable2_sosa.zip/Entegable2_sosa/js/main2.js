
// array de objetos multas

const multas = 
[
	{id:"010",fecha:"12/09/14",patente:"UCL399",monto:7500,lugar:"Lobos"},
	{id:"015",fecha:"21/03/14",patente:"MNU050",monto:12000,lugar:"La Plata"},
	{id:"021",fecha:"05/01/15",patente:"JKT113",monto:12000,lugar:"Olivos"},
	{id:"026",fecha:"30/11/16",patente:"UCL399",monto:12000,lugar:"Ensenada"},
	{id:"041",fecha:"01/12/16",patente:"DLU098",monto:4500,lugar:"Rauch"},
	{id:"077",fecha:"21/12/16",patente:"UCL399",monto:4500,lugar:"25 de Mayo"},
	{id:"083",fecha:"!2/09/17",patente:"MNU050",monto:7500,lugar:"San Fernando"},
	{id:"110",fecha:"22/09/18",patente:"UCL399",monto:7500,lugar:"Avellaneda"},
	{id:"125",fecha:"13/09/19",patente:"JYR312",monto:4500,lugar:"Zárate"},
	{id:"210",fecha:"09/09/19",patente:"MNU050",monto:17500,lugar:"San Isidro"},
];


let patente ="";
const hoy = new Date();

let botonBuscar = document.getElementById("btnBuscar");
//botonBuscar.onclick = () => {encontrar_patente(document.getElementById('inputPatente').value); document.getElementById("parrABorrar").style.display = "none";}
botonBuscar.onclick = () => {encontrar_patente(document.getElementById('inputPatente').value); document.getElementById("aOcultar").style.display = "none";}
//botonBuscar.onclick = () => {encontrar_patente(document.getElementById('inputPatente').value); ocultar_comentario();}

let botonReset = document.getElementById("btnRecargar");
botonReset.onclick = () => location.reload();




function encontrar_patente(unaPatente)
{
	let esta = false;
	// busco en array patentes
	
	//let total_
	let encabezadoPatente = false;
	for (const multa of multas)
	{
		if (multa.patente == unaPatente.toUpperCase())
		{
			// si no tiene encabezado la patente
			if (!encabezadoPatente)
			{
				let div_encabezado_multa = document.createElement("div");
				div_encabezado_multa.className = "divEncabezado";
				div_encabezado_multa.innerHTML = `<h2> Al día de la fecha ${dar_fecha(hoy)}, la patente: ${unaPatente.toUpperCase()} registra las siguientes multas:</h2>`;
				document.body.appendChild(div_encabezado_multa);
				encabezadoPatente = true;
			}
			
			esta = true;
			// muestro la multa
			let contenedorMulta = document.createElement("div");
			contenedorMulta.innerHTML = `<h3> ID de Multa: ${multa.id}</h3><p> Lugar: ${multa.lugar}</p><p>  Fecha: ${multa.fecha}</p><b>  Monto ${multa.monto}</b>`;
			document.body.appendChild(contenedorMulta);
		} 
	} 
	// si es una patente sin multas
	if (!esta)
	{
		let msgNoMultas = document.createElement("div");
		msgNoMultas.className = "divNoMultas";
		msgNoMultas.innerHTML = `<h2> Al día de la fecha ${dar_fecha(hoy)}, la patente: ${unaPatente.toUpperCase()}</h2><p><b>No registras multas.</b></p>`;
		document.body.appendChild(msgNoMultas);
	} 	
	else
	{
		
	}		
} 		
	
function dar_fecha(fecha) 
{
	let dd = fecha.getDate();
	let mm = fecha.getMonth() + 1;
	let aa = fecha.getFullYear().toString().slice(-2);
	return dd + "/" + mm + "/"+ aa;
}
