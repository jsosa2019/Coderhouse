## proyecto final, alumno javier sosa

//Objetivo
## la aplicación web tiene como objetivo encontrar multas correspondientes a una patente determinada.
## luego de listarlas permite seleccionar cuales se desea abonar.
## emula el pago de las multas

//Uso
## la patente se puede ingresar y consultar si presenta multas

//Archivos
## archivo json -> empleado para cargar las multas se encuentran en un archivo las_multas.json.
## archivo css -> subcarpeta /css -> archivo con hojas de estilo de index.html
## archivo js -> subcarpeta /js -> archivo con código javascript
## archivo html -> carpeta raíz ->  página html


//Comentario
## para verificar el funcionamiento dejo algunas patentes válidas

// const patentes = ["UCL399","MNU050","JKT113","DLU098","JYR312"];