
// array de multas
const multas = [];
const multasSelec = [];
let cont=0;	
let cantidadMultasBD = 0;
// hacer array de objetos para las multas seleccionadas



// recupero BD multas
cargar_Multas();


let patente ="";
let totalAPagar = 0;	
const hoy = new Date();

let botonBuscar = document.getElementById("btnBuscar");
botonBuscar.onclick = () => {encontrar_patente(document.getElementById('inputPatente').value)};

let botonReset = document.getElementById("btnRecargar");
botonReset.onclick = () => location.reload();

function encontrar_patente(unaPatente)
{
	let infractor = false;
	
	let encabezadoPatente = false;

	// recorro multas buscando patente ingresada

	for (const multa of multas)
	{
		if (multa.patente == unaPatente.toUpperCase())
		{
			// si no tiene encabezado la patente
			if (!encabezadoPatente)
			{
				let div_encabezado_multa = document.createElement("div");
				div_encabezado_multa.className = "divEncabezado";
				div_encabezado_multa.innerHTML = `<h2> Al día de la fecha ${dar_fecha(hoy)}, la patente: ${unaPatente.toUpperCase()} registra las siguientes multas:</h2>`;
				document.body.appendChild(div_encabezado_multa);
				encabezadoPatente = true;
			}
			
			infractor = true;
			// muestro la multa en web
			let contenedorMulta = document.createElement("div");
			let nombre_chk  = "'"+"chk_"+multa.id+"'";
			contenedorMulta.innerHTML = `<h3> Multa patente: ${multa.patente}</h3>
										<label for=${nombre_chk}> Multa: ${multa.id}</label>
									 	<input type = "checkbox" id= ${nombre_chk} onclick="seleccionado(${nombre_chk}, ${multa.monto})">
										<p> Lugar: ${multa.lugar}</p>
										<p>  Fecha: ${multa.fecha}</p>
										<p>  Monto <b>$ ${multa.monto} </b></p>`;
			document.body.appendChild(contenedorMulta);
		} 
	} 
	
	// <label for=${nombre_chk}> Multa: ${multa.id}</label><br>
	// si es una patente sin multas
	if (infractor)
	{
		// recorrer array con multas seleccionadas
		let totalMultasDiv = document.createElement("div");
		
		totalMultasDiv.innerHTML = `<h2 class="total"> Valor total multas a abonar: ${totalAPagar}</h2>
									<label>Abonar monto seleccionado: </label>
									<button id="btnPagar" class="btn pagar" onclick=mostrarSeleccion()>Aceptar</button>`;
		document.body.appendChild(totalMultasDiv);
	} 
	else
	{
		let msgNoMultas = document.createElement("div");
		msgNoMultas.className = "divNoMultas";
		msgNoMultas.innerHTML = `<h2> Al día de la fecha ${dar_fecha(hoy)}, la patente: ${unaPatente.toUpperCase()}</h2>
								<p><b>No registras multas.</b></p>`;
		document.body.appendChild(msgNoMultas);

	}	
} 		
	
function dar_fecha(fecha) 
{
	let dd = fecha.getDate();
	let mm = fecha.getMonth() + 1;
	let aa = fecha.getFullYear().toString().slice(-2);
	return dd + "/" + mm + "/"+ aa;
}


function cargar_Multas ()
{
	// recupero multas de BD y las cargo en array multas

	fetch("./db/las_multas.json")
			.then(respuestas => respuestas.json())
			.then(lasMultas => 
			{
				try 
				{
					if ( lasMultas.length == 0 )
					{
							throw new Error ("No es posible recuperar registros de la BD Multas");
					}
					else
					{
						lasMultas.forEach (unaMulta => 
							{
								multas.push(unaMulta);
					
							} )
					}
				} catch (error) 
				{
					// quitar controles de búsqueda
					// mostrar salida de no funcionamiento
					alert(error);
				} 
			});
}	

function seleccionado(cBoxId,unMonto)
{
	
	let caja = document.getElementById(cBoxId);

	let multID = cBoxId.split("_");
	if (caja.checked == true)
	{
		caja.parentNode.setAttribute("class", "seleccionado"); 
		totalAPagar = totalAPagar + unMonto;
		multasSelec.push(multID[1]);
		
	} 
	else 
	{
		caja.parentNode.setAttribute("class", "noSeleccionado"); 
		totalAPagar = totalAPagar - unMonto;
		eliminarDeArray(multID[1]);
	} 
	actualizarValorPago(totalAPagar);
}		

// actualizo el valor total a pagar
function actualizarValorPago(unMontoAPagar)
{
	// modifico el valor total a pagar
	let h2Pago = document.querySelector("h2.total");
	h2Pago.innerText='Valor total multas a abonar: '+ unMontoAPagar;
}


// elimino del array el id indicado
function eliminarDeArray(unValor)
{
	let indice = multasSelec.indexOf(unValor); 
	multasSelec.splice(indice, 1); 
	
}